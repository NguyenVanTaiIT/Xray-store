const AWSXRay = require('aws-xray-sdk');
const Product = require('../models/Product');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

// S3 client
const s3Client = new S3Client({ 
  region: process.env.AWS_REGION || 'ap-southeast-1',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY,
    secretAccessKey: process.env.AWS_SECRET_KEY
  }
});

// Helper function để xử lý X-Ray segment an toàn
const withXRay = (segmentName, fn) => async (...args) => {
  const segment = process.env.ENABLE_XRAY === 'true' 
    ? AWSXRay.getSegment()?.addNewSubsegment(segmentName) 
    : null;
  
  try {
    const result = await fn(...args);
    segment?.close();
    return result;
  } catch (err) {
    segment?.close(err);
    throw err;
  }
};

exports.getProducts = withXRay('GetProducts', async (req, res) => {
  const { category, brand, sort, page = 1, limit = 10 } = req.query;
  let query = {};

  if (category && category !== 'all') {
    query.category = new RegExp(`^${category}$`, 'i');
  }

  if (brand && brand !== 'all') {
    query.brand = new RegExp(`^${brand}$`, 'i');
  }

  let sortOption = {};
  if (sort === 'price-low') {
    sortOption.price = 1;
  } else if (sort === 'price-high') {
    sortOption.price = -1;
  } else if (sort === 'rating') {
    sortOption.rating = -1;
  }

  const totalCount = await Product.countDocuments(query);

  const allCategories = ['gaming', 'office', 'ultrabook'];
  const categoryCounts = {};
  for (const cat of allCategories) {
    const count = await Product.countDocuments({ category: new RegExp(`^${cat}$`, 'i') });
    categoryCounts[cat] = count;
  }
  categoryCounts.all = await Product.countDocuments({});

  const products = await Product.find(query)
    .sort(sortOption)
    .skip((page - 1) * limit)
    .limit(parseInt(limit));

  res.status(200).json({
    products,
    totalCount: totalCount || 0,
    totalPages: Math.ceil(totalCount / limit),
    currentPage: parseInt(page),
    categoryCounts
  });
});

exports.getProductById = withXRay('GetProductById', async (req, res) => {
  console.log(`Fetching product with ID: ${req.params.id}`);
  const product = await Product.findById(req.params.id);
  if (!product) {
    return res.status(404).json({ message: 'Sản phẩm không tồn tại' });
  }
  res.status(200).json(product);
});

exports.createProduct = withXRay('CreateProduct', async (req, res) => {
  const {
    name, price, image, category, brand, specs, stockQuantity, warranty,
    storage, display, os, battery, weight, featuresDescription, description, sku
  } = req.body;

  if (!name || !price || !image || !category || !brand || !sku) {
    return res.status(400).json({ message: 'Vui lòng cung cấp đầy đủ thông tin sản phẩm' });
  }

  const existingProduct = await Product.findOne({ sku });
  if (existingProduct) {
    return res.status(400).json({ message: 'SKU đã tồn tại' });
  }

  const product = new Product({
    name,
    price,
    image,
    category,
    brand,
    specs: specs || [],
    stockQuantity: stockQuantity || 0,
    warranty: warranty || '24 tháng',
    storage: storage || '',
    display: display || '',
    os: os || '',
    battery: battery || '',
    weight: weight || '',
    featuresDescription: featuresDescription || '',
    description: description || '',
    sku,
    rating: 0,
    reviews: 0,
    inStock: (stockQuantity || 0) > 0,
    createdAt: new Date(),
    updatedAt: new Date()
  });

  await product.save();
  res.status(201).json(product);
});

exports.updateProduct = withXRay('UpdateProduct', async (req, res) => {
  console.log(`Updating product ID: ${req.params.id} with data: ${JSON.stringify(req.body)}`);
  const { id } = req.params;
  const {
    name, price, image, category, brand, specs, stockQuantity, warranty,
    storage, display, os, battery, weight, featuresDescription, description, sku
  } = req.body;

  const product = await Product.findById(id);
  if (!product) {
    return res.status(404).json({ message: 'Sản phẩm không tồn tại' });
  }

  if (sku && sku !== product.sku) {
    const existingProduct = await Product.findOne({ sku });
    if (existingProduct) {
      return res.status(400).json({ message: 'SKU đã tồn tại' });
    }
  }

  product.name = name !== undefined ? name : product.name;
  product.price = price !== undefined ? price : product.price;
  product.image = image !== undefined ? image : product.image;
  product.category = category !== undefined ? category : product.category;
  product.brand = brand !== undefined ? brand : product.brand;
  product.specs = specs !== undefined ? specs : product.specs;
  product.stockQuantity = stockQuantity !== undefined ? stockQuantity : product.stockQuantity;
  product.warranty = warranty !== undefined ? warranty : product.warranty;
  product.storage = storage !== undefined ? storage : product.storage;
  product.display = display !== undefined ? display : product.display;
  product.os = os !== undefined ? os : product.os;
  product.battery = battery !== undefined ? battery : product.battery;
  product.weight = weight !== undefined ? weight : product.weight;
  product.featuresDescription = featuresDescription !== undefined ? featuresDescription : product.featuresDescription;
  product.description = description !== undefined ? description : product.description;
  product.sku = sku !== undefined ? sku : product.sku;
  product.inStock = product.stockQuantity > 0;
  product.updatedAt = new Date();

  await product.save();
  res.status(200).json(product);
});

exports.deleteProduct = withXRay('DeleteProduct', async (req, res) => {
  console.log(`Deleting product with ID: ${req.params.id}`);
  const { id } = req.params;
  const product = await Product.findByIdAndDelete(id);
  if (!product) {
    return res.status(404).json({ message: 'Sản phẩm không tồn tại' });
  }
  res.status(200).json({ message: 'Sản phẩm đã được xóa' });
});

exports.addReview = withXRay('AddReview', async (req, res) => {
  const { rating, comment } = req.body;
  const userId = req.user.userId;
  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ message: 'Đánh giá phải từ 1 đến 5 sao' });
  }
  const product = await Product.findById(req.params.id);
  if (!product) {
    return res.status(404).json({ message: 'Không tìm thấy sản phẩm' });
  }
  const alreadyReviewed = product.reviewsData.find(r => r.userId.toString() === userId);
  if (alreadyReviewed) {
    return res.status(400).json({ message: 'Bạn đã đánh giá sản phẩm này' });
  }
  const user = await User.findById(userId);
  const review = {
    userId,
    name: user.name || 'Người dùng',
    rating: Number(rating),
    comment,
    createdAt: new Date()
  };
  product.reviewsData.push(review);
  product.updateRating();
  await product.save();
  res.status(201).json({ message: 'Đánh giá thành công', review });
});

exports.getReviewsForProduct = withXRay('GetReviewsForProduct', async (req, res) => {
  const { productId } = req.params;
  const product = await Product.findById(productId);
  if (!product) {
    return res.status(404).json({ message: 'Không tìm thấy sản phẩm' });
  }
  const reviews = product.reviewsData.sort((a, b) => b.createdAt - a.createdAt);
  res.json(reviews);
});

exports.searchProducts = withXRay('SearchProducts', async (req, res) => {
  const q = Array.isArray(req.query.q) ? req.query.q[0] : req.query.q;
  if (!q || typeof q !== 'string' || q.trim() === '') {
    console.warn('Invalid search query received:', q);
    return res.status(400).json({ message: 'Thiếu hoặc không hợp lệ từ khóa tìm kiếm' });
  }
  const results = await Product.find({
    name: { $regex: q.trim(), $options: 'i' },
  })
    .limit(5)
    .select('name');
  const suggestions = results.map((product) => product.name).filter(name => name && typeof name === 'string');
  console.log('Processed suggestions:', suggestions);
  res.json(suggestions);
});

exports.uploadProductImage = withXRay('UploadProductImage', async (req, res) => {
  const params = {
    Bucket: 'ecommerce-products-2025',
    Key: `products/${Date.now()}-${req.file.originalname}`,
    Body: req.file.buffer,
    ContentType: req.file.mimetype,
    ACL: 'public-read'
  };
  await s3Client.send(new PutObjectCommand(params));
  res.status(200).json({ imageUrl: `https://ecommerce-products-2025.s3.ap-southeast-1.amazonaws.com/${params.Key}` });
});